package Trabalho.Visao;

import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        new MenuInicial(new Scanner(System.in));

    }

}